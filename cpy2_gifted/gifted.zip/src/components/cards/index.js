import React, { Component } from "react";
import Card from "../card";
import "./style.css";
export default class Cards extends Component {

    render(props) {
        const {gifs} = this.props;
        const cardsComp = gifs.map(gif => {
            return <Card key={gif.id} data={gif} data-test="gifCard"/>
        }) || null
        // console.log("cardsComp :: ", cardsComp)
        return (
            <div className="cards" data-test="cardsComponent">
                {cardsComp}
            </div>
        )
    }
}