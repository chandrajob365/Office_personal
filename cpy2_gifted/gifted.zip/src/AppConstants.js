export const LIGHT = "light";
export const DARK = "dark";