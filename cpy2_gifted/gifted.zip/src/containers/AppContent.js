import React, { Component } from "react"
import Search from "../components/search";
import Cards from "../components/cards";
import "./style.css";
export default class AppContent extends Component {

    constructor(props){
        super(props);
        this.state = {
            gifs: [],
            limit: 25
        }
        this.searchText = "happy"
    }
    componentDidMount() {
        console.log("called")
        this.fetchGIF();
    }

    fetchGIF = () => {
        if(this.searchText){


        fetch(`https://api.giphy.com/v1/gifs/search?api_key=${process.env.REACT_APP_GIPHY_API_KEY}&q=${this.searchText}&limit=${this.state.limit}`)
                .then(response => {
                    console.log("fetchGIF", response)
                    return response.json()
                })
                .then(searchedResponse => {
                    console.log("searchedResponse :: ", searchedResponse)
                    return this.setState({gifs: searchedResponse.data})
                })
                .catch(err => console.log("Error :: ", err))
        }
    }

    debounceFetchGIF = (fn, limit) => {
        let timer;
        return () => {
            timer && clearTimeout(timer);
            timer = setTimeout(fn, limit);
        }
    };

    handleDebouncedSearchEvent = this.debounceFetchGIF(this.fetchGIF, 300);

    updateSearchText = (searchText) => {
        this.searchText = searchText && searchText.length > 0 ? searchText : "happy";
        this.handleDebouncedSearchEvent();
    }

    render() {
        const { gifs } = this.state;
        return (
            <div className="app_content" data-test="appContent">
                <Search updateSearchText={this.updateSearchText}/>
                <Cards data-test="cardInAppContent" gifs={gifs}/>
            </div>
        )
    }
}